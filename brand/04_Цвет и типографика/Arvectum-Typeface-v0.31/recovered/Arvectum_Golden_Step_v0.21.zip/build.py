from pathlib import Path
import math, json, hashlib, zipfile, xml.etree.ElementTree as ET, sys
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.svgLib.path import parse_path
from shapely.geometry import Polygon
from shapely.affinity import translate
import numpy as np
from html import escape
O=Path(__file__).parent
src=O/'sources'/'Arvectum_Golden_Wordmark_v0.19.zip'
z=zipfile.ZipFile(src)
phi=(1+math.sqrt(5))/2; sn=math.sin(math.atan(phi)); co=math.cos(math.atan(phi)); H=180.16; W=291.505003413; cap=1490; xh=1056; navy='#001432'; mint='#41B599'
words={'EN':'Arvectum','RU':'Арвектум'}; chars=list(dict.fromkeys(''.join(words.values())))
mon=z.read('sources/AV_Golden_v018_mint.svg'); assert hashlib.sha256(mon).hexdigest()=='9fc4b52cee3aee4c2412e9264a1e2882ccade506673d0dc7f0c8f478a8674eb8'; mp=ET.fromstring(mon)[0].attrib['d']
base={c:ET.fromstring(z.read(f'glyphs/C/U+{ord(c):04X}.svg'))[0].attrib['d'] for c in chars}
old=json.loads(z.read('metrics.json'))['layout']['C']
def f(x):return f'{x:.6f}'.rstrip('0').rstrip('.') or '0'
def xy(x,y):return f'{f(x)} {f(y)}'
def rec(d): r=RecordingPen();parse_path(d,r);return r
def bounds(d): b=BoundsPen(None);rec(d).replay(b);return b.bounds
def poly(d):
 rings=[];cur=[]
 for op,pts in rec(d).value:
  if op=='moveTo':cur=[pts[0]]
  elif op=='lineTo':cur.append(pts[0])
  elif op=='curveTo':
   a,b,c,e=map(np.array,[cur[-1],*pts]);cur.extend(tuple((1-t)**3*a+3*(1-t)**2*t*b+3*(1-t)*t*t*c+t**3*e) for t in np.linspace(0,1,81)[1:])
  elif op=='closePath':
   p=Polygon(cur);assert p.is_valid and p.area>0,(d,p.wkt[:160]);rings.append(p);cur=[]
  else:raise ValueError(op)
 p=rings[0]
 for q in rings[1:]:assert p.contains(q);p=p.symmetric_difference(q)
 assert p.is_valid;return p
def make(k):
 # k=1: optical geometry preserving baseline saturation. k>1: controlled weight test.
 td=cap*22.359347787/H*k; s=184*k; h=cap/(2*phi**3)*k; o=td/sn; tip=cap/phi**6; a=cap/phi; w=2*a+tip; inn=cap-(2*o-tip)*phi/2; center=cap/phi**2; yb=center-h/2; yt=center+h/2; gap=cap/phi**6/sn
 xl=lambda y:y/phi+o; xr=lambda y:w-xl(y)
 D=dict(base);D['A']=D['А']=f'M{xy(a,cap)} H{f(a+tip)} L{xy(w,0)} H{f(w-o)} L{xy(w/2,inn)} L{xy(xl(yt),yt)} H{f(xr(yt)-gap)} L{xy(xr(yb)-gap,yb)} H{f(xl(yb))} L{xy(o,0)} H0 Z'
 # Maintain the selected exact golden diagonal and a small flat vertex for v.
 flat=xh/phi**6; wv=2*xh/phi+flat; yi=(2*o-flat)*phi/2
 D['v']=f'M0 {xh} H{f(o)} L{xy(wv/2,yi)} L{xy(wv-o,xh)} H{f(wv)} L{xy((wv+flat)/2,0)} H{f((wv-flat)/2)} Z'
 # r: shorter terminal, exact golden cut, smooth shoulder transition.
 D['r']=f'M0 0 V1056 H{f(s)} V800 C{f(s+78)} 956 382 1071 590 1071 L{xy(590-175/phi,896)} C350 896 {f(s)} 750 {f(s)} 500 V0 Z'
 # t: quieter ascender (1240), exact golden terminal, consistent vertical stem and crossbar.
 top=1240; ts=180*k; left=187; right=left+s; d=176*k; bottom=1056-d
 D['t']=f'M{f(left)} {f(top-144)} L{xy(left+144/phi,top)} H{f(right)} V1056 H620 V{f(bottom)} H{f(right)} V270 C{f(right)} 185 465 {f(170*k)} 620 {f(170*k)} V0 C330 0 {f(left)} 78 {f(left)} 270 V{f(bottom)} H0 V1056 H{f(left)} Z'
 # Cyrillic м: less acute central valley, exact golden slants, even stroke.
 y=xh/phi; dx=(xh-y)/phi; cx=s+dx; wm=2*cx; drop=s/co
 D['м']=f'M0 0 V1056 H{f(s)} L{xy(cx,y)} L{xy(wm-s,xh)} H{f(wm)} V0 H{f(wm-s)} V{f(xh-drop)} L{xy(cx,y-drop)} L{xy(s,xh-drop)} V0 Z'
 # у: exact parallel diagonals, straight descender, same normal stroke as v.
 wy=1263; yu=xh-(wy-2*o)*phi/2; yl=xh-(wy-o)*phi/2; xd=wy-(xh+350)/phi
 D['у']=f'M0 1056 H{f(o)} L{xy(wy/2,yu)} L{xy(wy-o,xh)} H{f(wy)} L{xy(xd,-350)} H{f(xd-o)} L{xy((xh-yl)/phi,yl)} Z'
 # к: choose diagonals for readability, solve horizontal terminal widths for equal normal thickness.
 # center junction is at (s,528), top and bottom stroke edges start at the stem.
 # slopes chosen from reference, not forced to golden angle.
 xt=905.; xb=920.; mu=(1056-528)/(xt-s-100); ml=528/(xb-s-100)
 ht=td*math.sqrt(1+mu**2)/mu; hb=td*math.sqrt(1+ml**2)/ml
 # lower upper edge and upper lower edge intersect at a common sharp junction.
 # right-side outgoing edges through (xt,1056) and (xb,0).
 a0=1056-mu*xt; b0=ml*xb; jx=(b0-a0)/(mu+ml); jy=mu*jx+a0
 D['к']=f'M0 0 V1056 H{f(s)} V{f(mu*s+a0+mu*ht)} L{xy(xt-ht,1056)} H{f(xt)} L{xy(jx,jy)} L{xy(xb,0)} H{f(xb-hb)} L{xy(s,b0-ml*s-ml*hb)} V0 Z'
 # c/e: retain curve envelope; smooth and thicken inner counter only in weighted test.
 D['c']=f'M874 905 L769 735 C705 852 575 {f(1071-175*k)} 445 {f(1071-175*k)} C245 {f(1071-175*k)} {f(s)} 768 {f(s)} 528 C{f(s)} 288 245 {f(-15+175*k)} 445 {f(-15+175*k)} C575 {f(-15+175*k)} 707 204 771 321 L877 151 C812 33 652 -15 445 -15 C145 -15 0 152 0 528 C0 904 145 1071 445 1071 C652 1071 809 1023 874 905 Z'
 ey=500; ey2=ey+175*k; eb=-15+175*k; et=1071-175*k
 D['e']=D['е']=f'M{f(s)} 500 C{f(s)} 271 277 {f(eb)} 475 {f(eb)} C598 {f(eb)} 683 200 821 315 L927 145 C831 32 655 -15 475 -15 C155 -15 0 154 0 528 C0 888 155 1071 475 1071 C786 1071 950 887 950 580 V500 H{f(s)} Z M{xy(s+7,ey2)} H{f(950-s-8)} C735 820 654 {f(et)} 475 {f(et)} C300 {f(et)} 219 830 {xy(s+7,ey2)} Z'
 # Other straight/curved stems: inner boundaries only, unchanged outer silhouette.
 D['u']=f'M0 1056 H{f(s)} V403 C{f(s)} 228 263 {f(eb)} 454 {f(eb)} C648 {f(eb)} {f(940-s)} 266 {f(940-s)} 443 V1056 H940 V0 H{f(940-s)} V163 C662 46 546 -15 402 -15 C141 -15 0 115 0 415 Z'
 # m: slightly shortened shoulders, two consistent stem weights, retain width.
 D['m']=f'M0 0 V1056 H{f(s)} V846 C265 995 367 1071 478 1071 C647 1071 747 997 800 831 C891 1003 1007 1071 1160 1071 C1370 1071 1480 922 1480 661 V0 H{f(1480-s)} V642 C{f(1480-s)} 808 1243 {f(1071-186*k)} 1117 {f(1071-186*k)} C943 {f(1071-186*k)} {f(740+s/2)} 790 {f(740+s/2)} 625 V0 H{f(740-s/2)} V642 C{f(740-s/2)} 808 595 {f(1071-186*k)} 470 {f(1071-186*k)} C296 {f(1071-186*k)} {f(s)} 790 {f(s)} 625 V0 Z'
 D['р']=f'M0 -350 V1056 H{f(s)} V854 C285 1000 398 1071 500 1071 C793 1071 940 883 940 528 C940 173 793 -15 500 -15 C363 -15 250 60 {f(s)} 178 V-350 Z M{f(s)} 528 C{f(s)} 266 283 {f(eb)} 500 {f(eb)} C685 {f(eb)} {f(940-s)} 266 {f(940-s)} 528 C{f(940-s)} 790 674 {f(et)} 500 {f(et)} C288 {f(et)} {f(s)} 790 {f(s)} 528 Z'
 D['в']=f'M0 0 V1056 H455 C752 1056 868 961 868 789 C868 663 802 574 695 543 C831 521 920 430 920 270 C920 87 778 0 455 0 Z M{f(s)} {f(168*k)} H455 C639 {f(168*k)} {f(920-s)} 186 {f(920-s)} 279 C{f(920-s)} 390 631 {f(528-96*k)} 455 {f(528-96*k)} H{f(s)} Z M{f(s)} {f(528+75*k)} H455 C623 {f(528+75*k)} {f(868-s)} 663 {f(868-s)} 788 C{f(868-s)} 861 624 {f(1056-168*k)} 455 {f(1056-168*k)} H{f(s)} Z'
 D['т']=f'M0 1056 H940 V{f(1056-176*k)} H{f(470+s/2)} V0 H{f(470-s/2)} V{f(1056-176*k)} H0 Z'
 return D
variants={'A':base,'B':make(1),'C':make(1+phi**-5)}
# baseline positions from source; optical pair targets, scale in cap units.
target={'Ar':(125,190),'rv':(102,170),'ve':(105,184),'ec':(112,164),'ct':(110,160),'tu':(115,160),'um':(120,155),'Ар':(125,190),'рв':(115,155),'ве':(110,155),'ек':(114,154),'кт':(115,155),'ту':(110,155),'ум':(115,154)}
def profile(p):
 yy=np.arange(-345,1490,5);a=np.array(p.exterior.coords);p0=a[:-1];p1=a[1:];l=[];r=[]
 for y in yy:
  sel=((p0[:,1]<=y)&(p1[:,1]>y))|((p1[:,1]<=y)&(p0[:,1]>y));aa=p0[sel];bb=p1[sel];xx=aa[:,0]+(y-aa[:,1])*(bb[:,0]-aa[:,0])/(bb[:,1]-aa[:,1]);l.append(min(xx) if len(xx) else np.nan);r.append(max(xx) if len(xx) else np.nan)
 return np.array(l),np.array(r)
def layout(lang,D,k):
 word=words[lang]; ps={c:poly(D[c]) for c in set(word)}; pr={c:profile(p) for c,p in ps.items()};pos=[0.]; pairs=[]
 for i,(a,b) in enumerate(zip(word,word[1:])):
  l,r=pr[b][0],pr[a][1];sel=np.isfinite(l)&np.isfinite(r);delta=l[sel]-r[sel];t,q=target[a+b];step=old[lang]['positions'][i+1]-old[lang]['positions'][i] if k=='A' else math.ceil(max(t-delta.min(),q-np.quantile(delta,.25))/2)*2
  d=ps[a].distance(translate(ps[b],xoff=step))
  while k!='A' and d<92:step+=2;d=ps[a].distance(translate(ps[b],xoff=step))
  assert d>0;pos.append(pos[-1]+step);pairs.append({'pair':a+b,'step':step,'min_distance':d})
 return pos,pairs

def svg(vb,body):return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}">{body}</svg>'
def save(n,s):p=O/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(s);ET.parse(p)
def text(x,y,s,size=21,weight=400):return f'<text x="{x}" y="{y}" font-family="DejaVu Sans,sans-serif" font-size="{size}" font-weight="{weight}" fill="{navy}">{escape(s)}</text>'
records={}; bodies={}
for k,D in variants.items():
 records[k]={};bodies[k]={}
 for c,d in D.items():
  poly(d);x0,y0,x1,y1=bounds(d);save(f'glyphs/{k}/U+{ord(c):04X}.svg',svg(f'0 0 {f(x1-x0)} {f(y1-y0)}',f'<path fill="{navy}" fill-rule="evenodd" transform="translate({f(-x0)} {f(y1)}) scale(1 -1)" d="{d}"/>'))
 for lang,word in words.items():
  pos,pairs=layout(lang,D,k);xmax=max(x+bounds(D[c])[2] for c,x in zip(word,pos));ymin=min(bounds(D[c])[1] for c in word);ymax=max(bounds(D[c])[3] for c in word);body=''.join(f'<path d="{D[c]}" transform="translate({f(x)} 0)" fill="{navy}" fill-rule="evenodd"/>' for c,x in zip(word,pos));save(f'{k}_Wordmark_{lang}.svg',svg(f'0 0 {f(xmax)} {f(ymax-ymin)}',f'<g transform="translate(0 {f(ymax)}) scale(1 -1)">{body}</g>'))
  scale=H/math.sqrt(phi)/cap; xx=W+H/phi**3; yy=H/2+cap*scale/2-(H*.025 if lang=='RU' else 0); vh=max(H,yy-ymin*scale); vw=xx+xmax*scale
  block=f'<path fill="{mint}" d="{mp}"/><g transform="translate({f(xx)} {f(yy)}) scale({f(scale)} {f(-scale)})">{body}</g>';save(f'{k}_Lockup_{lang}.svg',svg(f'0 0 {f(vw)} {f(vh)}',block));bodies[k][lang]=block;records[k][lang]={'word_width':xmax,'positions':pos,'pairs':pairs,'lockup_width':vw,'lockup_height':vh,'ink_area':sum(poly(D[c]).area for c in word)}
labels={'A':'0.19 C · исходная Golden Step','B':'0.21 B · оптическая редакция','C':'0.21 C · усиление штриха +9,02%'}
body='<rect width="1520" height="880" fill="white"/>'+text(48,57,'Arvectum Golden Step / 0.21',35,700)+text(48,95,'Монограмма 0.18 неизменна · открытая A · одинаковые пропорции логоблока',19)+text(48,138,'EN / Arvectum',20,700)+text(790,138,'RU / Арвектум',20,700)
for i,k in enumerate(variants):
 y=164+224*i;body+=f'<path d="M48 {y}H1472" stroke="#C8D2DC"/>'+text(48,y+34,labels[k],21,600)
 for lang,x in [('EN',48),('RU',790)]:body+=f'<g transform="translate({x} {y+77}) scale(.52)">{bodies[k][lang]}</g>'
body+=text(48,853,'Диагностические цвета. Варианты B/C — не утверждённые мастера.',18);save('Comparison.svg',svg('0 0 1520 880',body))
body='<rect width="1500" height="825" fill="white"/>'+text(45,55,'Golden Step / детали и малый масштаб',32,700)
for i,k in enumerate(variants):
 x=45+i*480; body+=text(x,108,labels[k],20,600);D=variants[k];dx=0
 for c in 'Arvм':
  body+=f'<g transform="translate({x+dx} 264) scale(.08 -.08)"><path fill="{navy}" fill-rule="evenodd" d="{D[c]}"/></g>';dx+=(bounds(D[c])[2]+80)*.08
 for j,size in enumerate([16,24,32,48]):
  y=310+j*110;body+=text(x,y+15,f'{size} px',15)
  for l,offy in [('EN',0),('RU',size+6)]:body+=f'<g transform="translate({x+65} {y+offy}) scale({size/H})">{bodies[k][l]}</g>'
body+=text(45,805,'Размер указывает высоту монограммы. Никаких растровых элементов.',18);save('Details_and_Sizes.svg',svg('0 0 1500 825',body))
(O/'metrics.json').write_text(json.dumps({'phi':phi,'angle_deg':math.degrees(math.atan(phi)),'weight_factor_C':1+phi**-5,'layout':records},ensure_ascii=False,indent=2))
print(json.dumps({k:{l:{'width':round(v['word_width'],1),'min_gap':round(min(p['min_distance'] for p in v['pairs']),2),'ink_area':round(v['ink_area'])} for l,v in a.items()} for k,a in records.items()},ensure_ascii=False,indent=2))
